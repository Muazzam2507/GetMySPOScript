﻿namespace GetMySPOScript
{
    partial class frm_CreateSite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_CreateSingleSite = new System.Windows.Forms.Button();
            this.btn_CreateMultipleSites = new System.Windows.Forms.Button();
            this.btn_Home = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 19);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(829, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please select from the below options (i.e. whether you need a script for a single" +
    " site or multiple sites)";
            // 
            // btn_CreateSingleSite
            // 
            this.btn_CreateSingleSite.Location = new System.Drawing.Point(23, 99);
            this.btn_CreateSingleSite.Name = "btn_CreateSingleSite";
            this.btn_CreateSingleSite.Size = new System.Drawing.Size(233, 65);
            this.btn_CreateSingleSite.TabIndex = 1;
            this.btn_CreateSingleSite.Text = "Create Single Site";
            this.btn_CreateSingleSite.UseVisualStyleBackColor = true;
            this.btn_CreateSingleSite.Click += new System.EventHandler(this.btn_CreateSingleSite_Click);
            // 
            // btn_CreateMultipleSites
            // 
            this.btn_CreateMultipleSites.Location = new System.Drawing.Point(23, 242);
            this.btn_CreateMultipleSites.Name = "btn_CreateMultipleSites";
            this.btn_CreateMultipleSites.Size = new System.Drawing.Size(233, 65);
            this.btn_CreateMultipleSites.TabIndex = 2;
            this.btn_CreateMultipleSites.Text = "Create multiple Sites";
            this.btn_CreateMultipleSites.UseVisualStyleBackColor = true;
            this.btn_CreateMultipleSites.Click += new System.EventHandler(this.btn_CreateMultipleSites_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.Location = new System.Drawing.Point(575, 374);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Size = new System.Drawing.Size(233, 65);
            this.btn_Home.TabIndex = 3;
            this.btn_Home.Text = "Home Page";
            this.btn_Home.UseVisualStyleBackColor = true;
            this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click);
            // 
            // frm_CreateSite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(885, 496);
            this.Controls.Add(this.btn_Home);
            this.Controls.Add(this.btn_CreateMultipleSites);
            this.Controls.Add(this.btn_CreateSingleSite);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_CreateSite";
            this.ShowIcon = false;
            this.Text = "GetMySPOScript";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_CreateSite_FormClosing);
            this.Load += new System.EventHandler(this.frm_CreateSite_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_CreateSingleSite;
        private System.Windows.Forms.Button btn_CreateMultipleSites;
        private System.Windows.Forms.Button btn_Home;
    }
}