﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetMySPOScript
{
    public partial class frm_CreateSite : Form
    {
        public frm_CreateSite()
        {
            InitializeComponent();
        }

        private void btn_Home_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();

        }

        private void btn_CreateSingleSite_Click(object sender, EventArgs e)
        {
            frm_SingleSite singleSite = new frm_SingleSite();
            singleSite.Show();
            this.Hide();
        }

        private void frm_CreateSite_Load(object sender, EventArgs e)
        {

        }

        private void frm_CreateSite_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_CreateMultipleSites_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This module is under development");
        }
    }
}
