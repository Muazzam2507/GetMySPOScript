﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GetMySPOScript
{
    public partial class frm_DelSingleSite : Form
    {
        public static string folderPath;
        public frm_DelSingleSite()
        {
            InitializeComponent();
        }

        private void btn_Home_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                folderPath = folderBrowserDialog1.SelectedPath;
                MessageBox.Show("Your script will be saved here => " + folderPath);

            }
        }

        private void btn_CreateScript_Click(object sender, EventArgs e)
        {
            string fileName = Path.Combine(folderPath, "DeleteSingleSPOSite.ps1");
            // Script taken from : https://www.sharepointdiary.com/2015/02/delete-site-collection-in-sharepoint-online-using-powershell.html
            string script = "#Load SharePoint CSOM Assemblies\n" +
                "Add-Type -Path \"C:\\Program Files\\Common Files\\Microsoft Shared\\Web Server Extensions\\16\\ISAPI\\Microsoft.SharePoint.Client.dll\"\n" +
                "Add-Type -Path \"C:\\Program Files\\Common Files\\Microsoft Shared\\Web Server Extensions\\16\\ISAPI\\Microsoft.SharePoint.Client.Runtime.dll\"\n" +
                "Add-Type -Path \"C:\\Program Files\\SharePoint Online Management Shell\\Microsoft.Online.SharePoint.PowerShell\\Microsoft.Online.SharePoint.Client.Tenant.dll\"\n" +
                "#delete site collection sharepoint online powershell\n" +
                "Function Remove-SPOSiteCollection($AdminCenterURL,$SiteURL)\n" +
                "{\n" +
                "Try {\n" +
                "#Setup Credentials to connect\n" +
                "$Cred= Get-Credential\n" +
                "#Setup the Context\n" +
                "$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($AdminCenterURL)\n" +
                "$Ctx.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)\n" +
                "#Get the tenant object\n" +
                "$Tenant = New-Object Microsoft.Online.SharePoint.TenantAdministration.Tenant($Ctx)\n" +
                "Write-Host -f Yellow \"Deleting site collection...\"\n" +
                "#delete a sharepoint online site powershell\n" +
                "$Tenant.RemoveSite($SiteURL)\n" +
                "#$Tenant.RemoveDeletedSite($SiteURL) #To delete site from recycle bin!\n" +
                "$ctx.ExecuteQuery()\n" +
                "Write-host \"Site Collection Deleted Successfully!\" -foregroundcolor Green\n" +
                "}\n" +
                "catch {\n" +
                "write-host \"Error: $($_.Exception.Message)\" -foregroundcolor Red\n" +
                "}\n" +
                "}\n" +
                "#Set Parameters\n" +
                "$AdminCenterURL = \""+ txt_AdminSite.Text.ToString() +"\"\n" +
                "$SiteURL = \""+ txt_Site.Text.ToString() +"\"\n" +
                "#Call the function to delete site collection\n" +
                "Remove-SPOSiteCollection $AdminCenterURL $SiteURL\n";

            try
            {
                // Check if file already exists. If yes, delete it.     
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                // Create a new file     
                using (FileStream fs = File.Create(fileName))
                {
                    // Add some text to file    
                    Byte[] title = new UTF8Encoding(true).GetBytes(script);
                    fs.Write(title, 0, title.Length);
                    MessageBox.Show("Script created successfully...");
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void frm_DelSingleSite_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }
    }
}
