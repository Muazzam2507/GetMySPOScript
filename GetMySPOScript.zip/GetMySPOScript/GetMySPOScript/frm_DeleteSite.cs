﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetMySPOScript
{
    public partial class frm_DeleteSite : Form
    {
        public frm_DeleteSite()
        {
            InitializeComponent();
        }

        private void btn_Home_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void btn_SingleSiteDelete_Click(object sender, EventArgs e)
        {
            frm_DelSingleSite delSingleSite = new frm_DelSingleSite();
            delSingleSite.Show();
            this.Hide();
        }

        private void frm_DeleteSite_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_MultiSiteDelete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This module is under development");
        }
    }
}
