﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GetMySPOScript
{
    public partial class frm_GetSingleSite : Form
    {
        public static string folderPath;

        public frm_GetSingleSite()
        {
            InitializeComponent();
        }

        private void btn_Browse_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                folderPath = folderBrowserDialog1.SelectedPath;
                MessageBox.Show("Your script will be saved here => " + folderPath);

            }
        }

        private void frm_GetSingleSite_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_CreateScript_Click(object sender, EventArgs e)
        {
            string fileName = Path.Combine(folderPath, "GetSingleSPOSite.ps1");

            string script = "#Load SharePoint CSOM Assemblies\n" +
                            "Add-Type -Path \"C:\\Program Files\\Common Files\\Microsoft Shared\\Web Server Extensions\\16\\ISAPI\\Microsoft.SharePoint.Client.dll\"\n" +
                            "Add-Type -Path \"C:\\Program Files\\Common Files\\Microsoft Shared\\Web Server Extensions\\16\\ISAPI\\Microsoft.SharePoint.Client.Runtime.dll\"\n" +
                            "#Variables\n" +
                            "$SiteURL=\""+ txt_SiteURL.Text.ToString() +"\"\n" +
                            "Try {\n" +
                            "$Cred= Get-Credential\n" +
                            "$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)\n" +
                            "#Setup the context\n" +
                            "$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)\n" +
                            "$Ctx.Credentials = $Credentials\n" +
                            "#Get the Site from URL\n" +
                            "$Web = $Ctx.web\n" +
                            "$Ctx.Load($web)\n" +
                            "$Ctx.ExecuteQuery()\n" +
                            "#Get the current site title and ID\n" +
                            "Write-host \"Site Title: \"$web.title\n" +
                            "Write-Host \"Site Id:\" $web.Id\n" +
                            "}\n" +
                            "Catch {\n" +
                            "write-host -f Red \"Error Updating Site Title!\" $_.Exception.Message\n" +
                            "}\n";

            try
            {
                // Check if file already exists. If yes, delete it.     
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                // Create a new file     
                using (FileStream fs = File.Create(fileName))
                {
                    // Add some text to file    
                    Byte[] title = new UTF8Encoding(true).GetBytes(script);
                    fs.Write(title, 0, title.Length);
                    MessageBox.Show("Script created successfully...");
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void frm_GetSingleSite_Load(object sender, EventArgs e)
        {

        }
    }
}
