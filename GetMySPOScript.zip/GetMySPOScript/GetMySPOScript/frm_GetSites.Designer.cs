﻿using System;

namespace GetMySPOScript
{
    partial class frm_GetSites
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_SingleSite = new System.Windows.Forms.Button();
            this.btn_MultiSites = new System.Windows.Forms.Button();
            this.btn_AllSites = new System.Windows.Forms.Button();
            this.btn_Home = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label1.Location = new System.Drawing.Point(10, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(901, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please select from the below options (i.e. whether you need a script for a single" +
    " site, multiple sites or all sites)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_SingleSite
            // 
            this.btn_SingleSite.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SingleSite.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_SingleSite.Location = new System.Drawing.Point(12, 75);
            this.btn_SingleSite.Name = "btn_SingleSite";
            this.btn_SingleSite.Size = new System.Drawing.Size(341, 58);
            this.btn_SingleSite.TabIndex = 1;
            this.btn_SingleSite.Text = "Single Site";
            this.btn_SingleSite.UseVisualStyleBackColor = true;
            this.btn_SingleSite.Click += new System.EventHandler(this.btn_SingleSite_Click);
            // 
            // btn_MultiSites
            // 
            this.btn_MultiSites.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MultiSites.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_MultiSites.Location = new System.Drawing.Point(14, 179);
            this.btn_MultiSites.Name = "btn_MultiSites";
            this.btn_MultiSites.Size = new System.Drawing.Size(341, 58);
            this.btn_MultiSites.TabIndex = 2;
            this.btn_MultiSites.Text = "Multiple Sites";
            this.btn_MultiSites.UseVisualStyleBackColor = true;
            this.btn_MultiSites.Click += new System.EventHandler(this.btn_MultiSites_Click);
            // 
            // btn_AllSites
            // 
            this.btn_AllSites.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AllSites.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_AllSites.Location = new System.Drawing.Point(14, 288);
            this.btn_AllSites.Name = "btn_AllSites";
            this.btn_AllSites.Size = new System.Drawing.Size(341, 58);
            this.btn_AllSites.TabIndex = 3;
            this.btn_AllSites.Text = "All Sites";
            this.btn_AllSites.UseVisualStyleBackColor = true;
            this.btn_AllSites.Click += new System.EventHandler(this.btn_AllSites_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_Home.Location = new System.Drawing.Point(548, 369);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Size = new System.Drawing.Size(341, 58);
            this.btn_Home.TabIndex = 4;
            this.btn_Home.Text = "Home Page";
            this.btn_Home.UseVisualStyleBackColor = true;
            this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click);
            // 
            // frm_GetSites
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(916, 450);
            this.Controls.Add(this.btn_Home);
            this.Controls.Add(this.btn_AllSites);
            this.Controls.Add(this.btn_MultiSites);
            this.Controls.Add(this.btn_SingleSite);
            this.Controls.Add(this.label1);
            this.Name = "frm_GetSites";
            this.ShowIcon = false;
            this.Text = "GetMySPOScript";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_GetSites_FormClosing);
            this.Load += new System.EventHandler(this.frm_GetSites_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void frm_GetSites_Load(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_SingleSite;
        private System.Windows.Forms.Button btn_MultiSites;
        private System.Windows.Forms.Button btn_AllSites;
        private System.Windows.Forms.Button btn_Home;
    }
}