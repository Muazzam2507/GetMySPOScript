﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetMySPOScript
{
    public partial class frm_GetSites : Form
    {
        public frm_GetSites()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Home_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void btn_SingleSite_Click(object sender, EventArgs e)
        {
            frm_GetSingleSite getSingleSite = new frm_GetSingleSite();
            getSingleSite.Show();
            this.Hide();
        }

        private void frm_GetSites_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_MultiSites_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This module is under development");
        }

        private void btn_AllSites_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This module is under development");
        }
    }
}
