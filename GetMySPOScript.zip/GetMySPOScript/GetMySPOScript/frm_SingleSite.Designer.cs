﻿namespace GetMySPOScript
{
    partial class frm_SingleSite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_GenScript = new System.Windows.Forms.Button();
            this.btn_Home = new System.Windows.Forms.Button();
            this.txt_URL = new System.Windows.Forms.TextBox();
            this.txt_Template = new System.Windows.Forms.TextBox();
            this.txt_Owner = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.btn_FolderDialog = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_AdminSite = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(12, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(433, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please provide the values for the below parameters:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(17, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Site URL : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(17, 215);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Site Template : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(17, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Site Owner : ";
            // 
            // btn_GenScript
            // 
            this.btn_GenScript.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_GenScript.ForeColor = System.Drawing.Color.Blue;
            this.btn_GenScript.Location = new System.Drawing.Point(40, 380);
            this.btn_GenScript.Name = "btn_GenScript";
            this.btn_GenScript.Size = new System.Drawing.Size(273, 58);
            this.btn_GenScript.TabIndex = 5;
            this.btn_GenScript.Text = "Generate PS Script";
            this.btn_GenScript.UseVisualStyleBackColor = true;
            this.btn_GenScript.Click += new System.EventHandler(this.btn_GenScript_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home.ForeColor = System.Drawing.Color.Blue;
            this.btn_Home.Location = new System.Drawing.Point(486, 380);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Size = new System.Drawing.Size(273, 58);
            this.btn_Home.TabIndex = 6;
            this.btn_Home.Text = "Home Page";
            this.btn_Home.UseVisualStyleBackColor = true;
            this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click);
            // 
            // txt_URL
            // 
            this.txt_URL.Location = new System.Drawing.Point(183, 157);
            this.txt_URL.Name = "txt_URL";
            this.txt_URL.Size = new System.Drawing.Size(361, 22);
            this.txt_URL.TabIndex = 7;
            // 
            // txt_Template
            // 
            this.txt_Template.Location = new System.Drawing.Point(183, 215);
            this.txt_Template.Name = "txt_Template";
            this.txt_Template.Size = new System.Drawing.Size(361, 22);
            this.txt_Template.TabIndex = 9;
            // 
            // txt_Owner
            // 
            this.txt_Owner.Location = new System.Drawing.Point(183, 266);
            this.txt_Owner.Name = "txt_Owner";
            this.txt_Owner.Size = new System.Drawing.Size(361, 22);
            this.txt_Owner.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(17, 327);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(489, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Select folder where you want to save the PS Script locally : ";
            // 
            // btn_FolderDialog
            // 
            this.btn_FolderDialog.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_FolderDialog.ForeColor = System.Drawing.Color.Blue;
            this.btn_FolderDialog.Location = new System.Drawing.Point(573, 323);
            this.btn_FolderDialog.Name = "btn_FolderDialog";
            this.btn_FolderDialog.Size = new System.Drawing.Size(103, 28);
            this.btn_FolderDialog.TabIndex = 12;
            this.btn_FolderDialog.Text = "Browse";
            this.btn_FolderDialog.UseVisualStyleBackColor = true;
            this.btn_FolderDialog.Click += new System.EventHandler(this.btn_FolderDialog_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(17, 99);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Admin Site URL :";
            // 
            // txt_AdminSite
            // 
            this.txt_AdminSite.Location = new System.Drawing.Point(183, 97);
            this.txt_AdminSite.Name = "txt_AdminSite";
            this.txt_AdminSite.Size = new System.Drawing.Size(361, 22);
            this.txt_AdminSite.TabIndex = 14;
            // 
            // frm_SingleSite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txt_AdminSite);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btn_FolderDialog);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Owner);
            this.Controls.Add(this.txt_Template);
            this.Controls.Add(this.txt_URL);
            this.Controls.Add(this.btn_Home);
            this.Controls.Add(this.btn_GenScript);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frm_SingleSite";
            this.ShowIcon = false;
            this.Text = "GetMySPOScript";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_SingleSite_FormClosing);
            this.Load += new System.EventHandler(this.frm_SingleSite_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_GenScript;
        private System.Windows.Forms.Button btn_Home;
        private System.Windows.Forms.TextBox txt_URL;
        private System.Windows.Forms.TextBox txt_Template;
        private System.Windows.Forms.TextBox txt_Owner;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button btn_FolderDialog;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_AdminSite;
    }
}