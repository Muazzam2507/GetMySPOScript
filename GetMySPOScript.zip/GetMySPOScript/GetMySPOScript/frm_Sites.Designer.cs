﻿namespace GetMySPOScript
{
    partial class frm_Sites
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_CreateSite = new System.Windows.Forms.Button();
            this.btn_GetSites = new System.Windows.Forms.Button();
            this.btn_UpdateSite = new System.Windows.Forms.Button();
            this.btn_DeleteSite = new System.Windows.Forms.Button();
            this.btn_Home = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(591, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please select the site operation that you need to generate the script for:";
            // 
            // btn_CreateSite
            // 
            this.btn_CreateSite.Location = new System.Drawing.Point(15, 67);
            this.btn_CreateSite.Name = "btn_CreateSite";
            this.btn_CreateSite.Size = new System.Drawing.Size(262, 60);
            this.btn_CreateSite.TabIndex = 1;
            this.btn_CreateSite.Text = "Create Site";
            this.btn_CreateSite.UseVisualStyleBackColor = true;
            this.btn_CreateSite.Click += new System.EventHandler(this.btn_CreateSite_Click);
            // 
            // btn_GetSites
            // 
            this.btn_GetSites.Location = new System.Drawing.Point(15, 166);
            this.btn_GetSites.Name = "btn_GetSites";
            this.btn_GetSites.Size = new System.Drawing.Size(262, 60);
            this.btn_GetSites.TabIndex = 2;
            this.btn_GetSites.Text = "Get Sites";
            this.btn_GetSites.UseVisualStyleBackColor = true;
            this.btn_GetSites.Click += new System.EventHandler(this.btn_GetSites_Click);
            // 
            // btn_UpdateSite
            // 
            this.btn_UpdateSite.Location = new System.Drawing.Point(15, 263);
            this.btn_UpdateSite.Name = "btn_UpdateSite";
            this.btn_UpdateSite.Size = new System.Drawing.Size(262, 60);
            this.btn_UpdateSite.TabIndex = 3;
            this.btn_UpdateSite.Text = "Update Site";
            this.btn_UpdateSite.UseVisualStyleBackColor = true;
            this.btn_UpdateSite.Click += new System.EventHandler(this.btn_UpdateSite_Click);
            // 
            // btn_DeleteSite
            // 
            this.btn_DeleteSite.Location = new System.Drawing.Point(15, 365);
            this.btn_DeleteSite.Name = "btn_DeleteSite";
            this.btn_DeleteSite.Size = new System.Drawing.Size(262, 60);
            this.btn_DeleteSite.TabIndex = 4;
            this.btn_DeleteSite.Text = "Delete Site";
            this.btn_DeleteSite.UseVisualStyleBackColor = true;
            this.btn_DeleteSite.Click += new System.EventHandler(this.btn_DeleteSite_Click);
            // 
            // btn_Home
            // 
            this.btn_Home.Location = new System.Drawing.Point(15, 477);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Size = new System.Drawing.Size(0, 0);
            this.btn_Home.TabIndex = 5;
            this.btn_Home.Text = "Home Page";
            this.btn_Home.UseVisualStyleBackColor = true;
            this.btn_Home.Click += new System.EventHandler(this.button5_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(448, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(262, 60);
            this.button1.TabIndex = 6;
            this.button1.Text = "Home Page";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frm_Sites
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Home);
            this.Controls.Add(this.btn_DeleteSite);
            this.Controls.Add(this.btn_UpdateSite);
            this.Controls.Add(this.btn_GetSites);
            this.Controls.Add(this.btn_CreateSite);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Blue;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_Sites";
            this.ShowIcon = false;
            this.Text = "GetMySPOScript";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_Sites_FormClosing);
            this.Load += new System.EventHandler(this.frm_Sites_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_CreateSite;
        private System.Windows.Forms.Button btn_GetSites;
        private System.Windows.Forms.Button btn_UpdateSite;
        private System.Windows.Forms.Button btn_DeleteSite;
        private System.Windows.Forms.Button btn_Home;
        private System.Windows.Forms.Button button1;
    }
}