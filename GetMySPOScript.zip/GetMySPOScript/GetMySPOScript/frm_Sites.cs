﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetMySPOScript
{
    public partial class frm_Sites : Form
    {
        public frm_Sites()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void btn_CreateSite_Click(object sender, EventArgs e)
        {
            frm_CreateSite createSite = new frm_CreateSite();
            createSite.Show();
            this.Hide();
        }

        private void btn_DeleteSite_Click(object sender, EventArgs e)
        {
            frm_DeleteSite deleteSite = new frm_DeleteSite();
            deleteSite.Show();
            this.Hide();
        }

        private void btn_GetSites_Click(object sender, EventArgs e)
        {
            frm_GetSites getSites = new frm_GetSites();
            getSites.Show();
            this.Hide();
        }

        private void frm_Sites_Load(object sender, EventArgs e)
        {

        }

        private void frm_Sites_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_UpdateSite_Click(object sender, EventArgs e)
        {
            frm_UpdateSite updateSite = new frm_UpdateSite();
            updateSite.Show();
            this.Hide();
        }
    }
}
