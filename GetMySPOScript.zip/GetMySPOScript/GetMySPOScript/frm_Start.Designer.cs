﻿namespace GetMySPOScript
{
    partial class frm_Start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.btn_sites1 = new System.Windows.Forms.Button();
            this.btn_Lists1 = new System.Windows.Forms.Button();
            this.btn_Users1 = new System.Windows.Forms.Button();
            this.btn_Library1 = new System.Windows.Forms.Button();
            this.btn_Home1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(5, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(598, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Please choose the SPO Object you need scrpt for from the below options";
            // 
            // btn_sites1
            // 
            this.btn_sites1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sites1.ForeColor = System.Drawing.Color.Blue;
            this.btn_sites1.Location = new System.Drawing.Point(10, 69);
            this.btn_sites1.Name = "btn_sites1";
            this.btn_sites1.Size = new System.Drawing.Size(224, 62);
            this.btn_sites1.TabIndex = 1;
            this.btn_sites1.Text = "Sites";
            this.btn_sites1.UseVisualStyleBackColor = true;
            this.btn_sites1.Click += new System.EventHandler(this.btn_sites1_Click);
            // 
            // btn_Lists1
            // 
            this.btn_Lists1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Lists1.ForeColor = System.Drawing.Color.Blue;
            this.btn_Lists1.Location = new System.Drawing.Point(12, 161);
            this.btn_Lists1.Name = "btn_Lists1";
            this.btn_Lists1.Size = new System.Drawing.Size(224, 62);
            this.btn_Lists1.TabIndex = 2;
            this.btn_Lists1.Text = "Lists";
            this.btn_Lists1.UseVisualStyleBackColor = true;
            this.btn_Lists1.Click += new System.EventHandler(this.btn_Lists1_Click);
            // 
            // btn_Users1
            // 
            this.btn_Users1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Users1.ForeColor = System.Drawing.Color.Blue;
            this.btn_Users1.Location = new System.Drawing.Point(9, 344);
            this.btn_Users1.Name = "btn_Users1";
            this.btn_Users1.Size = new System.Drawing.Size(224, 62);
            this.btn_Users1.TabIndex = 3;
            this.btn_Users1.Text = "Users";
            this.btn_Users1.UseVisualStyleBackColor = true;
            this.btn_Users1.Click += new System.EventHandler(this.btn_Users1_Click);
            // 
            // btn_Library1
            // 
            this.btn_Library1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Library1.ForeColor = System.Drawing.Color.Blue;
            this.btn_Library1.Location = new System.Drawing.Point(10, 250);
            this.btn_Library1.Name = "btn_Library1";
            this.btn_Library1.Size = new System.Drawing.Size(224, 62);
            this.btn_Library1.TabIndex = 4;
            this.btn_Library1.Text = "Library";
            this.btn_Library1.UseVisualStyleBackColor = true;
            this.btn_Library1.Click += new System.EventHandler(this.btn_Library1_Click);
            // 
            // btn_Home1
            // 
            this.btn_Home1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home1.ForeColor = System.Drawing.Color.Blue;
            this.btn_Home1.Location = new System.Drawing.Point(576, 344);
            this.btn_Home1.Name = "btn_Home1";
            this.btn_Home1.Size = new System.Drawing.Size(224, 62);
            this.btn_Home1.TabIndex = 5;
            this.btn_Home1.Text = "Home Page";
            this.btn_Home1.UseVisualStyleBackColor = true;
            this.btn_Home1.Click += new System.EventHandler(this.btn_Home1_Click);
            // 
            // frm_Start
            // 
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(847, 462);
            this.Controls.Add(this.btn_Home1);
            this.Controls.Add(this.btn_Library1);
            this.Controls.Add(this.btn_Users1);
            this.Controls.Add(this.btn_Lists1);
            this.Controls.Add(this.btn_sites1);
            this.Controls.Add(this.label2);
            this.Name = "frm_Start";
            this.ShowIcon = false;
            this.Text = "GetMySPOScript";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm_Start_FormClosing);
            this.Load += new System.EventHandler(this.frm_Start_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Lists;
        private System.Windows.Forms.Button btn_Library;
        private System.Windows.Forms.Button btn_User;
        private System.Windows.Forms.Button btn_Home;
        private System.Windows.Forms.Button btn_Sites;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_sites1;
        private System.Windows.Forms.Button btn_Lists1;
        private System.Windows.Forms.Button btn_Users1;
        private System.Windows.Forms.Button btn_Library1;
        private System.Windows.Forms.Button btn_Home1;
    }
}