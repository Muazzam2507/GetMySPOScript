﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetMySPOScript
{
    public partial class frm_UpdateSite : Form
    {
        public frm_UpdateSite()
        {
            InitializeComponent();
        }

        private void frm_UpdateSite_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_Home_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void btn_ModifyTitle_Click(object sender, EventArgs e)
        {
            frm_UpdateSiteTitle updateSiteTitle = new frm_UpdateSiteTitle();
            updateSiteTitle.Show();
            this.Hide();
        }
    }
}
