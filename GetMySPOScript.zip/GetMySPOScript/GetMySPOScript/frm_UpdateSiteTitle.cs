﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GetMySPOScript
{
    public partial class frm_UpdateSiteTitle : Form
    {
        public static string folderPath;


        public frm_UpdateSiteTitle()
        {
            InitializeComponent();
        }

        private void frm_UpdateSiteTitle_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(1);
        }

        private void btn_Home_Click(object sender, EventArgs e)
        {
            frm_Welcome welcome = new frm_Welcome();
            welcome.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                folderPath = folderBrowserDialog1.SelectedPath;
                MessageBox.Show("Your script will be saved here => " + folderPath);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fileName = Path.Combine(folderPath, "UpdateSPOSiteTitle.ps1");
            // Script taken from : https://www.sharepointdiary.com/2018/01/sharepoint-online-change-site-title-using-powershell.html
            string script = "#Load SharePoint CSOM Assemblies\n" +
                "Add-Type -Path \"C:\\Program Files\\Common Files\\Microsoft Shared\\Web Server Extensions\\16\\ISAPI\\Microsoft.SharePoint.Client.dll\"\n" +
                "Add-Type -Path \"C:\\Program Files\\Common Files\\Microsoft Shared\\Web Server Extensions\\16\\ISAPI\\Microsoft.SharePoint.Client.Runtime.dll\"\n" +
                "#Variables\n" +
                "$SiteURL=\"" + txt_SiteURL.Text.ToString() + "\"\n" +
                "$NewSiteTitle=\"" + txt_SiteTitle.Text.ToString() + "\"\n" +
                "Try {\n" +
                "$Cred= Get-Credential\n" +
                "$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Cred.Username, $Cred.Password)\n" +
                "#Setup the context\n" +
                "$Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)\n" +
                "$Ctx.Credentials = $Credentials\n" +
                "#Get the Site from URL\n" +
                "\n$Web = $Ctx.web " +
                "#sharepoint online powershell change site title\n" +
                "$web.Title = $NewSiteTitle\n" +
                "$Web.Update()\n" +
                "$Ctx.ExecuteQuery()\n" +
                "Write-host \"Site Title has been updated to '$NewSiteTitle'\" -ForegroundColor Green\n" +
                "}\n" +
                "Catch {\n" +
                "write-host -f Red \"Error Updating Site Title!\" $_.Exception.Message\n" +
            "}\n";

            try
            {
                // Check if file already exists. If yes, delete it.     
                if (File.Exists(fileName))
                {
                    File.Delete(fileName);
                }

                // Create a new file     
                using (FileStream fs = File.Create(fileName))
                {
                    // Add some text to file    
                    Byte[] title = new UTF8Encoding(true).GetBytes(script);
                    fs.Write(title, 0, title.Length);
                    MessageBox.Show("Script created successfully...");
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
    }
}
